<TS language="pam" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>I-right click ban alilan ing address o libel</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Maglalang kang bayung address</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Bayu</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopyan me ing salukuyan at makipiling address keng system clipboard</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopyan</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>I&amp;sara</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Ilako ya ing kasalungsungan makapiling address keng listahan</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Magpalub kang address o label para pantunan</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Ilako</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Pilinan ing address a magpadalang coins kang</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Pilinan ing address a tumanggap coins a atin</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>P&amp;ilinan</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Address king pamag-Send</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Address king pamag-Tanggap</translation>
    </message>
    <message>
        <source>These are your Mind addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Reni reng kekang Mind address king pamagpadalang kabayaran. Lawan mulang masalese reng alaga ampo ing address na ning tumanggap bayu ka magpadalang barya.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Kopyan ing address</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Kopyan ing &amp;Label</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Alilan</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma separated file (*.csv)</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Address</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(alang label)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Dialogo ning Passphrase</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Mamalub kang passphrase</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Panibayung passphrase</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Pasibayuan ya ing bayung passphrase</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>I-encrypt ye ing wallet</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Ing operasyun a ini kailangan ne ing kekayung wallet passphrase, ban a-unlock ya ing wallet</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Unlock ya ing wallet</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Ing operasyun a ini kailangan ne ing kekang wallet passphrase ban a-decrypt ne ing wallet.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>I-decrypt ya ing wallet</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Alilan ya ing passphrase</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Kumpirman ya ing wallet encryption</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR MINDS&lt;/b&gt;!</source>
        <translation>Kapabaluan: Istung in-encrypt me ing kekang wallet at meala ya ing passphrase na, ma-&lt;b&gt;ALA NO NGAN RING KEKANG MINDS&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Siguradu na kang buri meng i-encrypt ing kekang wallet?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Me-encrypt ne ing wallet</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>Mayalaga: Reng milabas a backups a gewa mu gamit ing wallet file mu dapat lamung mialilan bayung gawang encrypted wallet file. Para keng seguridad , reng milabas a backups dareng ali maka encrypt a wallet file ma-ala nala istung inumpisan mu nalang gamitan reng bayu, at me encrypt a wallet. </translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Memali ya ing pamag-encrypt king wallet </translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Memali ya ing encryption uli na ning ausan dang internal error. E ya me-encrypt ing wallet yu.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>E la mitutugma ring mibieng passphrase</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Memali ya ing pamag-unlock king wallet </translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>E ya istu ing passphrase a pepalub da para king wallet decryption</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Me-mali ya ing pamag-decrypt king wallet</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Mi-alilan ne ing passphrase na ning wallet.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Kapabaluan: Makabuklat ya ing Caps Lock key!</translation>
    </message>
</context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>MindGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>I-sign ing &amp;mensayi</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Mag-sychronize ne king network...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Overview</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Ipakit ing kabuuang lawe ning wallet</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transaksion</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Lawan ing kasalesayan ning transaksion</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>L&amp;umwal</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Tuknangan ing aplikasyon</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Tungkul &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Magpakit impormasion tungkul king Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Pipamilian...</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>I-&amp;Encrypt in Wallet...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>I-&amp;Backup ing Wallet...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Alilan ing Passphrase...</translation>
    </message>
    <message>
        <source>Send coins to a Mind address</source>
        <translation>Magpadalang barya king Mind address</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>I-backup ing wallet king aliwang lugal</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Alilan ya ing passphrase a gagamitan para king wallet encryption</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Beripikan ing message...</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Ipalto / Isalikut</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Ipalto o isalikut ing pun a awang</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Pamag-ayus</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Saup</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Gamit para king Tabs</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>Pipamilian &amp;command-line</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Ing tatauling block a metanggap,  me-generate ya %1 ing milabas</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Ing transaksion kaibat na nini ali yapa magsilbing ipakit.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Mali</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Kapabaluan</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>&amp;Impormasion</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Makatuki ya king aldo</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Awang</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Catching up...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Mipadalang transaksion</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Paparatang a transaksion</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Maka-&lt;b&gt;encrypt&lt;/b&gt; ya ing wallet at kasalukuyan yang maka-&lt;b&gt;unlocked&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Maka-&lt;b&gt;encrypt&lt;/b&gt; ya ing wallet at kasalukuyan yang maka-&lt;b&gt;locked&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount:</source>
        <translation>Alaga:</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Alaga</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Kaaldauan</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Me-kumpirma</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopyan ing address</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopyan ing label</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopyan ing alaga</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(alang label)</translation>
    </message>
    </context>
<context>
    <name>CreateWalletActivity</name>
    </context>
<context>
    <name>CreateWalletDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Alilan ing Address</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Label</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Address</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Bayung address king pamagpadala</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Alilan ya ing address king pamagpadala</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Alilan ya ing address king pamagpadala</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Mind address.</source>
        <translation>Ing pepalub yung address "%1" ali ya katanggap-tanggap a Mind address.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Ali ya bisang mag-unlock ing wallet</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Memali ya ing pamangaua king key</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>bersion</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Pipamilian command-line</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Malaus ka</translation>
    </message>
    <message>
        <source>Mind</source>
        <translation>Mind</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Mali</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Tatauling oras na ning block</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OpenWalletActivity</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Pipamilian</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Pun</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Network</translation>
    </message>
    <message>
        <source>Automatically open the Mind client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Ibuklat yang antimanu ing Mind client port king router. Gagana yamu ini istung ing router mu susuporta yang UPnP at magsilbi ya.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Mapa ng ning port gamit ing &amp;UPnP</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Proxy &amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Port na ning proxy(e.g. 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Awang</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Ipakit mu ing tray icon kaibat meng pelatian ing awang.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Latian ya ing tray kesa king taskbar</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>P&amp;alatian istung isara</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Ipalto</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>Amanu na ning user interface:</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>Ing &amp;Unit a ipakit king alaga ning:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Pilinan ing default subdivision unit a ipalto o ipakit king interface at istung magpadala kang barya.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>I-&amp;Cancel</translation>
    </message>
    <message>
        <source>default</source>
        <translation>default</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Mali</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Ing milageng proxy address eya katanggap-tanggap.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Mind network after a connection is established, but this process has not completed yet.</source>
        <translation>Ing makaltong impormasion mapalyaring luma ne. Ing kekang wallet otomatiku yang mag-synchronize keng Mind network istung mekakonekta ne king network, oneng ing prosesung ini ali ya pa kumpletu.</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Ing kekang kasalungsungan balanse a malyari mung gastusan</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Ing kabuuan dareng transaksion a kasalungsungan ali pa me-kumpirma, at kasalungsungan ali pa mebilang kareng kekang balanseng malyari mung gastusan</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Immature:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Reng me-minang balanse a epa meg-matured</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Kabuuan:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Ing kekang kasalungsungan kabuuang balanse</translation>
    </message>
    </context>
<context>
    <name>PSBTOperationsDialog</name>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Alaga</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>e miya balu</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Bersion ning Cliente</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Impormasion</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Oras ning umpisa</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Network</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Bilang dareng koneksion</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Block chain</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Tatauling oras na ning block</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Ibuklat</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Console</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Kabuuan:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Debug log file</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>I-Clear ing console</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Label:</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopyan ing label</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopyan ing alaga</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Ali ya bisang mag-unlock ing wallet</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Amount:</source>
        <translation>Alaga:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Mensayi:</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>&amp;Kopyan ing address</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Kaaldauan</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mensayi</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(alang label)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Magpadalang Barya</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Kulang a pondo</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Alaga:</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Bayad king Transaksion:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Misanang magpadala kareng alialiuang tumanggap</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Maglage &amp;Tumanggap</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>I-Clear &amp;Eganagana</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Balanse:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Kumpirman ing aksion king pamagpadala</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;Ipadala</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopyan ing alaga</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Bayad king Transaksion</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Kumpirman ing pamagpadalang barya</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Ing alaga na ning bayaran dapat mung mas matas ya king 0.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Ing alaga mipasobra ya king kekang balanse.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Ing kabuuan mipasobra ya king kekang balanse istung inabe ya ing %1 a bayad king transaksion </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(alang label)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>A&amp;laga:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Ibayad &amp;kang:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Label:</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Idikit ing address menibat king clipboard</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Mensayi:</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Ibayad kang:</translation>
    </message>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Pirma - Pirman / I-beripika ing mensayi</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Pirman ing Mensayi</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Idikit ing address menibat king clipboard</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Ipalub ing mensayi a buri mung pirman keni</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Pirma</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Kopyan ing kasalungsungan pirma king system clipboard</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Mind address</source>
        <translation>Pirman ing mensayi ban patune na keka ya ining Mind address</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Pirman ing &amp;Mensayi</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Ibalik keng dati reng ngan fields keng pamamirmang mensayi</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>I-Clear &amp;Eganagana</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Beripikan ing Mensayi</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Mind address</source>
        <translation>Beripikan ing mensayi ban asiguradu a me pirma ya ini gamit ing mepiling Mind address</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Beripikan ing &amp;Mensayi</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Ibalik king dati reng ngan fields na ning pamag beripikang mensayi</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation>I-click ing "Pirman ing Mensayi" ban agawa ya ing metung a pirma</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Ing milub a address e ya katanggap-tanggap.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Maliaring pakilawe pasibayu ing address at pasibayuan ya iti.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>Ing milub a address ali ya mag-refer king metung a key.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Me-kansela ya ing pamag-unlock king wallet.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Ing private key para king milub a address, ala ya.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>Me-mali ya ing pamag-pirma king mensayi .</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Me-pirman ne ing mensayi.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Ing pirma ali ya bisang ma-decode.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>Maliaring pakilawe pasibayu ing pirma kaibat pasibayuan ya iti.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>Ing pirma ali ya makatugma king message digest.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>Me-mali ya ing pamag-beripika king mensayi.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>Me-beripika ne ing mensayi.</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Makabuklat anggang %1</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/ali me-kumpirma</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 kumpirmasion</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Kabilian</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Kaaldauan</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Pikuanan</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Megawa</translation>
    </message>
    <message>
        <source>From</source>
        <translation>Menibat</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>e miya balu</translation>
    </message>
    <message>
        <source>To</source>
        <translation>Para kang</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>sariling address</translation>
    </message>
    <message>
        <source>label</source>
        <translation>label</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>Credit</translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>ali metanggap</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>Debit</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Bayad king Transaksion</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>Alaga dareng eganagana</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Mensayi</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Komentu</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>Impormasion ning Debug</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>Transaksion</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Alaga</translation>
    </message>
    <message>
        <source>true</source>
        <translation>tutu</translation>
    </message>
    <message>
        <source>false</source>
        <translation>e tutu</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Ining pane a ini magpakit yang detalyadung description ning transaksion</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Kaaldauan</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Klase</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Makabuklat anggang %1</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Me-kumpirma(%1 kumpirmasion)</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Me-generate ya oneng ali ya metanggap</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Atanggap kayabe ning</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Atanggap menibat kang</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Mipadala kang</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Kabayaran keka</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Me-mina</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(alang label)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Status ning Transaksion: Itapat me babo na ning field a ini ban ipakit dala reng bilang dareng me-kumpirma na</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Aldo at oras nung kapilan me tanggap ya ing transaksion</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Klase ning transaksion</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Alagang milako o miragdag king balanse.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Eganagana</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Aldo iti</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Paruminggung iti</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Bulan a iti</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Milabas a bulan</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Banuang iti</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Angganan...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Atanggap kayabe ning</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Mipadala kang</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Keng sarili mu</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Me-mina</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Aliwa</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Pekaditak a alaga</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopyan ing address</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopyan ing label</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopyan ing alaga</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Alilan ing label</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Ipakit ing detalye ning transaksion</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma separated file (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Me-kumpirma</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Kaaldauan</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Klase</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Address</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Angga:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>para kang</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletController</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Magpadalang Barya</translation>
    </message>
    </context>
<context>
    <name>WalletView</name>
    <message>
        <source>Error</source>
        <translation>Mali</translation>
    </message>
    </context>
<context>
    <name>mind-core</name>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Mekapansin lang me-corrupt a block database</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Buri meng buuan pasibayu ing block database ngene?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Kamalian king pamag-initialize king block na ning database</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Kamalian king pamag buklat king block database</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Memali ya ing pamakiramdam kareng gang nanung port. Gamita me ini -listen=0 nung buri me ini.</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Maragul yang masiadu ing transaksion</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation>E kilalang network ing mepili king -onlynet: '%s'</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Kulang a pondo</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Lo-load dane ing block index...</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Lo-load dane ing wallet...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Ali ya magsilbing i-downgrade ing wallet</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>I-scan deng pasibayu...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Yari ne ing pamag-load</translation>
    </message>
</context>
</TS>